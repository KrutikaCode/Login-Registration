package com.company.dao;

public class User {
private String username;
private String email;
private String passowrd;
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getPassowrd() {
	return passowrd;
}
public void setPassowrd(String passowrd) {
	this.passowrd = passowrd;
}
//public void setUsername1(String username2) {
	// TODO Auto-generated method stub
	
}



